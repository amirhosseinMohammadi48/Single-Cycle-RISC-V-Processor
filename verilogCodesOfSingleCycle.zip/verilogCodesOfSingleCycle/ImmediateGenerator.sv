
module ImmediateGenerator (
    input [31:0] instruction,
    output reg [31:0] immediate
);
    wire [6:0]upcode = instruction[6:0];
    always @(*) begin

        case (upcode)
            
            //  R-Types
            7'b0110011:
                immediate = 32'd0;

            //  I-Types
            7'b0010011,7'b0000011,7'b1100111:
                immediate = {{20{instruction[31]}}, instruction[31:20]}; 
           
            // S-Types
            7'b0100011:
                immediate = {{20{instruction[31]}}, instruction[31:25] ,instruction[11:7]};
           
            // B-Types
            7'b1100011:
                immediate = {{19{instruction[31]}},instruction[31],instruction[7],instruction[30:25],instruction[11:8],1'b0};
             
            // J-Types
            7'b1101111:
                immediate = {{11{instruction[31]}},instruction[31],instruction[19:12],instruction[20],instruction[30:21],1'b0 };
            
            default:
                immediate = 32'd0;

        endcase
    end

endmodule